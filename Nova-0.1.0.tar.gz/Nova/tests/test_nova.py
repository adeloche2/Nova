from nova.engine import execute_source, check_source
from nova.errors import CompileError, RuntimeNovaError

def run(src):
    out = []
    execute_source(src, "test.nova", output=lambda *x: out.append(" ".join(map(str, x))))
    return out

def test_arithmetic_and_variables():
    assert run("x = 2 + 3 * 4\nprint(x)\n") == ["14"]

def test_if_else_and_while():
    src = "i = 0\nwhile i < 2:\n    print(i)\n    i = i + 1\nif i == 2:\n    print('done')\n"
    assert run(src) == ["0", "1", "done"]

def test_function():
    assert run("def add(a, b):\n    return a + b\nprint(add(5, 7))\n") == ["12"]

def test_class_and_method():
    src = "class Box:\n    def init(self, value):\n        self.value = value\n    def get(self):\n        return self.value\nb = Box(9)\nprint(b.get())\n"
    assert run(src) == ["9"]

def test_undefined_name():
    try:
        run("print(missing)\n")
        assert False
    except RuntimeNovaError as exc:
        assert "Undefined variable" in str(exc)

def test_compile_check():
    assert check_source("x = 1\n") is True

def test_reject_unsupported_syntax():
    try:
        check_source("for x in [1, 2]:\n    print(x)\n")
        assert False
    except CompileError:
        pass
