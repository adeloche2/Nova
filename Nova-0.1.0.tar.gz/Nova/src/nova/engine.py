from .compiler import Compiler
from .runtime import VM, make_builtins

def execute_source(source, filename="<source>", output=print):
    compiler = Compiler(filename)
    code = compiler.compile(source)
    vm = VM(output=output)
    make_builtins(vm.globals)
    return vm.run(code)

def check_source(source, filename="<source>"):
    Compiler(filename).compile(source)
    return True
