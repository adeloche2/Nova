from dataclasses import dataclass
from typing import Any

@dataclass
class Instruction:
    op: str
    arg: Any = None
    line: int | None = None

@dataclass
class CodeObject:
    name: str
    instructions: list[Instruction]
    parameters: list[str]
    filename: str
