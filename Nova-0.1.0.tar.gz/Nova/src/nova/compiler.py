import ast
from .bytecode import Instruction, CodeObject
from .errors import CompileError

BINOPS = {
    ast.Add: "ADD", ast.Sub: "SUB", ast.Mult: "MUL",
    ast.Div: "DIV", ast.FloorDiv: "FLOORDIV", ast.Mod: "MOD",
}
CMPOPS = {
    ast.Eq: "EQ", ast.NotEq: "NE", ast.Lt: "LT",
    ast.LtE: "LE", ast.Gt: "GT", ast.GtE: "GE",
}

class Compiler:
    def __init__(self, filename="<source>"):
        self.filename = filename
        self.code = []
        self.loop_stack = []

    def emit(self, op, arg=None, node=None):
        self.code.append(Instruction(op, arg, getattr(node, "lineno", None)))
        return len(self.code) - 1

    def patch(self, index, target):
        self.code[index].arg = target

    def compile(self, source):
        try:
            tree = ast.parse(source, filename=self.filename)
        except SyntaxError as exc:
            raise CompileError(exc.msg, self.filename, exc.lineno) from exc
        self.statements(tree.body)
        self.emit("CONST", None)
        self.emit("RETURN")
        return CodeObject("<main>", self.code, [], self.filename)

    def statements(self, body):
        for node in body:
            self.statement(node)

    def statement(self, node):
        if isinstance(node, ast.Assign):
            if len(node.targets) != 1:
                self.fail(node, "Chained assignment is not supported")
            target = node.targets[0]
            if isinstance(target, ast.Name):
                self.expression(node.value)
                self.emit("STORE", target.id, node)
            elif isinstance(target, ast.Attribute):
                self.expression(target.value)
                self.expression(node.value)
                self.emit("SET_ATTR", target.attr, node)
            else:
                self.fail(node, "Only variable and instance-attribute assignment is supported")
        elif isinstance(node, ast.Expr):
            self.expression(node.value)
            self.emit("POP", node=node)
        elif isinstance(node, ast.If):
            self.expression(node.test)
            jf = self.emit("JUMP_IF_FALSE", None, node)
            self.statements(node.body)
            if node.orelse:
                jend = self.emit("JUMP", None, node)
                self.patch(jf, len(self.code))
                self.statements(node.orelse)
                self.patch(jend, len(self.code))
            else:
                self.patch(jf, len(self.code))
        elif isinstance(node, ast.While):
            start = len(self.code)
            self.expression(node.test)
            jf = self.emit("JUMP_IF_FALSE", None, node)
            self.statements(node.body)
            self.emit("JUMP", start, node)
            self.patch(jf, len(self.code))
            if node.orelse:
                self.fail(node, "while-else is not supported")
        elif isinstance(node, ast.FunctionDef):
            if node.decorator_list or node.args.vararg or node.args.kwarg or node.args.kwonlyargs:
                self.fail(node, "Decorators and advanced function parameters are not supported")
            sub = Compiler(self.filename)
            sub.statements(node.body)
            sub.emit("CONST", None)
            sub.emit("RETURN")
            params = [a.arg for a in node.args.args]
            fn_code = CodeObject(node.name, sub.code, params, self.filename)
            self.emit("MAKE_FUNCTION", fn_code, node)
            self.emit("STORE", node.name, node)
        elif isinstance(node, ast.Return):
            if node.value is None:
                self.emit("CONST", None, node)
            else:
                self.expression(node.value)
            self.emit("RETURN", node=node)
        elif isinstance(node, ast.ClassDef):
            if node.bases or node.decorator_list or node.keywords:
                self.fail(node, "Inheritance and class decorators are not supported in Nova 0.1")
            methods = {}
            for item in node.body:
                if not isinstance(item, ast.FunctionDef):
                    self.fail(item, "A class body may contain method definitions only")
                sub = Compiler(self.filename)
                sub.statements(item.body)
                sub.emit("CONST", None)
                sub.emit("RETURN")
                params = [a.arg for a in item.args.args]
                if not params or params[0] != "self":
                    self.fail(item, "Instance methods must declare 'self' as the first parameter")
                methods[item.name] = CodeObject(item.name, sub.code, params, self.filename)
            self.emit("MAKE_CLASS", (node.name, methods), node)
            self.emit("STORE", node.name, node)
        else:
            self.fail(node, f"Unsupported statement: {type(node).__name__}")

    def expression(self, node):
        if isinstance(node, ast.Constant):
            if node.value is None or isinstance(node.value, (str, int, float, bool)):
                self.emit("CONST", node.value, node)
            else:
                self.fail(node, "Unsupported constant")
        elif isinstance(node, ast.Name):
            if node.id == "null":
                self.emit("CONST", None, node)
            elif node.id == "true":
                self.emit("CONST", True, node)
            elif node.id == "false":
                self.emit("CONST", False, node)
            else:
                self.emit("LOAD", node.id, node)
        elif isinstance(node, ast.BinOp) and type(node.op) in BINOPS:
            self.expression(node.left)
            self.expression(node.right)
            self.emit(BINOPS[type(node.op)], node=node)
        elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd, ast.Not)):
            self.expression(node.operand)
            self.emit({ast.USub: "NEG", ast.UAdd: "POS", ast.Not: "NOT"}[type(node.op)], node=node)
        elif isinstance(node, ast.Compare) and len(node.ops) == 1 and type(node.ops[0]) in CMPOPS:
            self.expression(node.left)
            self.expression(node.comparators[0])
            self.emit(CMPOPS[type(node.ops[0])], node=node)
        elif isinstance(node, ast.Call):
            if node.keywords:
                self.fail(node, "Keyword arguments are not supported yet")
            self.expression(node.func)
            for arg in node.args:
                self.expression(arg)
            self.emit("CALL", len(node.args), node)
        elif isinstance(node, ast.Attribute):
            self.expression(node.value)
            self.emit("GET_ATTR", node.attr, node)
        elif isinstance(node, ast.Subscript):
            self.fail(node, "Indexing is not supported in Nova 0.1")
        else:
            self.fail(node, f"Unsupported expression: {type(node).__name__}")

    def fail(self, node, message):
        raise CompileError(message, self.filename, getattr(node, "lineno", None))
