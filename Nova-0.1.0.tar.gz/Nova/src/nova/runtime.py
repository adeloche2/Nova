from dataclasses import dataclass
from .errors import RuntimeNovaError

@dataclass
class NovaFunction:
    code: object
    closure: dict

@dataclass
class NovaClass:
    name: str
    methods: dict

@dataclass
class NovaInstance:
    klass: NovaClass
    fields: dict

@dataclass
class BoundMethod:
    function: NovaFunction
    instance: NovaInstance

class VM:
    def __init__(self, output=print, max_steps=1_000_000):
        self.output = output
        self.max_steps = max_steps
        self.globals = {}
        self.steps = 0
        self.filename = "<source>"

    def run(self, code):
        self.filename = code.filename
        return self.execute(code, self.globals)

    def execute(self, code, env):
        stack = []
        ip = 0
        instructions = code.instructions
        while ip < len(instructions):
            ins = instructions[ip]
            self.steps += 1
            if self.steps > self.max_steps:
                self.error("Execution step limit exceeded", ins.line)
            op, arg = ins.op, ins.arg
            try:
                if op == "CONST": stack.append(arg)
                elif op == "LOAD":
                    if arg not in env: self.error(f"Undefined variable '{arg}'", ins.line)
                    stack.append(env[arg])
                elif op == "STORE": env[arg] = stack.pop()
                elif op == "POP": stack.pop()
                elif op == "ADD":
                    b, a = stack.pop(), stack.pop()
                    if isinstance(a, str) or isinstance(b, str): stack.append(str(a) + str(b))
                    else: stack.append(a + b)
                elif op == "SUB": b, a = stack.pop(), stack.pop(); stack.append(a - b)
                elif op == "MUL": b, a = stack.pop(), stack.pop(); stack.append(a * b)
                elif op == "DIV": b, a = stack.pop(), stack.pop(); stack.append(a / b)
                elif op == "FLOORDIV": b, a = stack.pop(), stack.pop(); stack.append(a // b)
                elif op == "MOD": b, a = stack.pop(), stack.pop(); stack.append(a % b)
                elif op == "NEG": stack.append(-stack.pop())
                elif op == "POS": stack.append(+stack.pop())
                elif op == "NOT": stack.append(not stack.pop())
                elif op == "EQ": b, a = stack.pop(), stack.pop(); stack.append(a == b)
                elif op == "NE": b, a = stack.pop(), stack.pop(); stack.append(a != b)
                elif op == "LT": b, a = stack.pop(), stack.pop(); stack.append(a < b)
                elif op == "LE": b, a = stack.pop(), stack.pop(); stack.append(a <= b)
                elif op == "GT": b, a = stack.pop(), stack.pop(); stack.append(a > b)
                elif op == "GE": b, a = stack.pop(), stack.pop(); stack.append(a >= b)
                elif op == "JUMP": ip = arg; continue
                elif op == "JUMP_IF_FALSE":
                    if not stack.pop(): ip = arg; continue
                elif op == "MAKE_FUNCTION": stack.append(NovaFunction(arg, env.copy()))
                elif op == "MAKE_CLASS": stack.append(NovaClass(arg[0], {k: NovaFunction(v, env.copy()) for k, v in arg[1].items()}))
                elif op == "GET_ATTR":
                    obj = stack.pop()
                    if isinstance(obj, NovaInstance):
                        if arg in obj.fields: stack.append(obj.fields[arg])
                        elif arg in obj.klass.methods: stack.append(BoundMethod(obj.klass.methods[arg], obj))
                        else: self.error(f"Object has no attribute '{arg}'", ins.line)
                    else: self.error("Attribute access is supported on Nova instances only", ins.line)
                elif op == "SET_ATTR":
                    value, obj = stack.pop(), stack.pop()
                    if not isinstance(obj, NovaInstance): self.error("Attribute assignment requires a Nova instance", ins.line)
                    obj.fields[arg] = value
                    stack.append(value)
                elif op == "CALL":
                    count = arg
                    args = stack[-count:] if count else []
                    if count: del stack[-count:]
                    callee = stack.pop()
                    if callee == "__nova_print__":
                        self.output(*args); stack.append(None)
                    elif isinstance(callee, BoundMethod):
                        stack.append(self.call(callee.function, [callee.instance] + args, ins.line))
                    elif isinstance(callee, NovaFunction):
                        stack.append(self.call(callee, args, ins.line))
                    elif isinstance(callee, NovaClass):
                        instance = NovaInstance(callee, {})
                        init = callee.methods.get("init")
                        if init:
                            self.call(init, [instance] + args, ins.line)
                        elif args:
                            self.error(f"{callee.name}() takes no arguments", ins.line)
                        stack.append(instance)
                    else: self.error("Value is not callable", ins.line)
                elif op == "RETURN": return stack.pop() if stack else None
                else: self.error(f"Unknown bytecode instruction '{op}'", ins.line)
            except RuntimeNovaError:
                raise
            except Exception as exc:
                self.error(f"{type(exc).__name__}: {exc}", ins.line)
            ip += 1
        return None

    def call(self, function, args, line):
        if len(args) != len(function.code.parameters):
            self.error(f"{function.code.name}() expects {len(function.code.parameters)} argument(s), got {len(args)}", line)
        local = function.closure.copy()
        local.update(zip(function.code.parameters, args))
        return self.execute(function.code, local)

    def error(self, message, line=None):
        raise RuntimeNovaError(message, self.filename, line)

def make_builtins(env):
    env["print"] = "__nova_print__"
