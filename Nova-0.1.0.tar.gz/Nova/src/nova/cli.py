import argparse
from pathlib import Path
from . import __version__
from .engine import execute_source, check_source
from .errors import NovaError

def main():
    parser = argparse.ArgumentParser(prog="nova", description="Nova language tools")
    parser.add_argument("--version", action="version", version=f"Nova {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)
    run_p = sub.add_parser("run", help="Run a .nova source file")
    run_p.add_argument("file")
    check_p = sub.add_parser("check", help="Compile-check a .nova source file")
    check_p.add_argument("file")
    args = parser.parse_args()
    path = Path(args.file)
    try:
        source = path.read_text(encoding="utf-8")
        if args.command == "run":
            execute_source(source, str(path))
        else:
            check_source(source, str(path))
            print(f"OK: {path}")
    except (OSError, NovaError) as exc:
        print(exc)
        raise SystemExit(1)
