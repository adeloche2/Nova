class NovaError(Exception):
    def __init__(self, message, filename="<source>", line=None):
        self.message = message
        self.filename = filename
        self.line = line
        where = f"{filename}:{line}" if line is not None else filename
        super().__init__(f"{where}: Nova error: {message}")


class CompileError(NovaError):
    pass


class RuntimeNovaError(NovaError):
    pass
