# Nova Bytecode 0.1

| Instruction | Purpose |
|---|---|
| CONST | Push constant |
| LOAD / STORE | Read/write variable |
| POP | Discard expression result |
| ADD SUB MUL DIV FLOORDIV MOD | Arithmetic |
| NEG POS NOT | Unary operators |
| EQ NE LT LE GT GE | Comparisons |
| JUMP | Unconditional branch |
| JUMP_IF_FALSE | Conditional branch |
| MAKE_FUNCTION | Create function value |
| MAKE_CLASS | Create class value |
| GET_ATTR | Read instance attribute or bound method |
| CALL | Call function, method, class or print |
| RETURN | Return from current frame |

Bytecode is currently held in memory as `CodeObject` and `Instruction` instances. A stable binary format is deferred until the instruction set stops changing.
