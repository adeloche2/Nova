# Nova Architecture

1. CLI loads UTF-8 source.
2. Front-end parses the restricted indentation-based source into a Python AST data structure. This AST is an implementation adapter only.
3. Compiler validates the supported Nova subset and emits Nova `Instruction` objects.
4. VM executes bytecode; it never executes source with `eval` or `exec`.
5. Runtime objects represent functions, classes, instances and bound methods.

The Python AST adapter is an intentional bootstrap shortcut. A later release should replace it with a dedicated Nova tokenizer and indentation-aware recursive-descent or Pratt parser, allowing Nova syntax to evolve independently of Python.
