# Nova 0.1 Language Specification (Draft)

## Decisions
- Dynamic typing.
- Significant indentation; four spaces recommended.
- Bytecode virtual machine.
- Classes and instance methods in 0.1.
- UTF-8 source files with `.nova` extension.

## Lexical and syntactic subset
The initial front-end accepts Python-like syntax, using `ast.parse` as a parser implementation detail. Nova semantics are defined by the compiler and VM, not by Python execution.

Supported statements:
- `name = expression`
- `print(expression, ...)`
- `if expression:` / optional `else:`
- `while expression:`
- `def name(parameters):`
- `return expression`
- `class Name:` with method definitions

Supported expressions:
- numeric, string, boolean and null literals
- variable references
- `+ - * / // %`
- unary `+ - not`
- one comparison: `== != < <= > >=`
- function calls
- attribute access

`true`, `false`, and `null` are Nova literals. Python spellings `True`, `False`, and `None` are also accepted by the current parser adapter.

## Object model
- Classes are values.
- Calling a class creates an instance.
- `init(self, ...)` is the constructor.
- Methods are bound to their instance on attribute lookup.
- Instance attributes are created by assignment to `self.attribute`.
- Inheritance is not implemented in 0.1.

## Execution model
The compiler emits Nova bytecode instructions. The VM executes those instructions using a value stack and environments. Function calls create local environments. The first version uses dictionary-backed environments; lexical closure capture is a snapshot and will be refined in a later release.

## Reserved future features
Lists, maps, imports, `for`, exceptions in source code, modules, static typing, bytecode serialization and package management.
