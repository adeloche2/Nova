# Nova Programming Language

Nova is an experimental general-purpose language for Windows. This repository is the first runnable milestone.

## Design decisions
- Dynamic typing.
- Indentation-based blocks.
- Custom bytecode instruction set and virtual machine.
- Basic classes, instances, attributes, methods and `init` constructor.
- Python is used only for the front-end parser and implementation runtime. Nova programs are **not** executed with `eval()` or `exec()`.

## Current syntax

Nova uses a deliberately small Python-like syntax:

```nova
name = "Nova"
count = 3

def greet(person):
    print("Hello", person)

class Counter:
    def init(self, start):
        self.value = start

    def increment(self):
        self.value = self.value + 1
        return self.value

counter = Counter(10)
print(counter.increment())
```

Conditionals and loops:

```nova
x = 0
while x < 3:
    print(x)
    x = x + 1

if x == 3:
    print("finished")
else:
    print("unexpected")
```

## Windows installation

1. Install Python 3.11 or newer and enable **Add Python to PATH**.
2. Extract this project, then open PowerShell in the `Nova` directory.
3. Create and activate a virtual environment:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, run:
`Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`

4. Install Nova in editable mode:

```powershell
python -m pip install --upgrade pip
python -m pip install -e .
```

5. Run a program:

```powershell
nova run examples\hello.nova
```

Or without installing the command:

```powershell
python -m nova run examples\hello.nova
```

Run tests:

```powershell
python -m pip install pytest
python -m pytest
```

## Commands

```powershell
nova run path\program.nova
nova check path\program.nova
nova --version
```

## Architecture

`source -> Python AST front-end -> Nova bytecode compiler -> Nova VM`

The front-end accepts a restricted Python-like grammar to make the first milestone reliable. The compiler translates accepted syntax into Nova's own bytecode. The VM executes only Nova bytecode. This is not a Python transpiler and does not execute source using Python's `eval` or `exec`.

## Implemented in 0.1

- Numbers, strings, booleans and `None` (written as `null`).
- Variables and assignment.
- Arithmetic and comparisons.
- `print(...)`.
- `if` / `else`, `while`.
- Functions, parameters and `return`.
- Classes, instance attributes, methods, `self`, and `init` constructor.
- Runtime errors with source file and line.

## Deliberate limitations of 0.1

- Lists/dictionaries, `for`, imports, modules, exceptions and a package manager are not implemented yet.
- The parser front-end currently uses Python's `ast` module, so the accepted grammar is a subset of Python syntax. A dedicated Nova lexer/parser is a planned milestone.
- No sandbox is claimed. Do not run untrusted Nova programs.
